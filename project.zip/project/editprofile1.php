<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {box-sizing: border-box;}
body { 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.header {
  overflow: hidden;
  background-color: #f1f1f1;
  padding: 20px 10px;
}

.header a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;
}

.header a.logo {
  font-size: 25px;
  font-weight: bold;
}

.header a:hover {
  background-color: #ddd;
  color: black;
}

.header a.active {
  background-color: dodgerblue;
  color: white;
}

.header-right {
  float: right;
}

@media screen and (max-width: 500px) {
  .header a {
    float: none;
    display: block;
    text-align: left;
  }
  .header-right {
    float: none;
  }
}
</style>
</head>
<body>
<?php
	$title="EditPackage";

		
	$name=$_GET['name'];
	$address=$_GET['address'];
	$city=$_GET['city'];
	$state=$_GET['state'];
	$phone=$_GET['phone'];
	$email=$_GET['email'];
	?>
<div class="header">
  <!--a href="#default" class="logo">CompanyLogo</a-->
  <div class="header-right">
    <a class="active" href="index.php">Home</a>
    <!--a href="#contact">Contact</a>
    <a href="#about">About</a-->
  </div>
</div>

<div class="container">
  		<form method="post" action="editPackageController.php?msg=update">
			<input type="hidden" name="id" value="<?php echo $id;?>"/></br></br>
  
    <div class="form-group">
      <label for="text">Name</label>
      <input type="text" class="form-control" id="name" placeholder="Enter name" name="name" value="<?php echo $name;?>">
    </div>
    <div class="form-group">
      <label for="text">Address</label>
      <input type="text" class="form-control" id="address" placeholder="Enter address" name="address" value="<?php echo $address;?>">
    </div>
	    <div class="form-group">
      <label for="text">City</label>
      <input type="text" class="form-control" id="city" placeholder="Enter City" name="city" value="<?php echo $city;?>">
    </div>
	<div class="form-group">
      <label for="date">State</label>
      <input type="text" class="form-control" id="state" placeholder="Enter state" name="state" value="<?php echo $state;?>">
    </div>
	<div class="form-group">
      <label for="date">Email</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" disabled="disabled" name="email" value="<?php echo $email;?>">
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
</div>

</body>
</html>
