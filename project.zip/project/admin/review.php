<?php
	include("MyDBClass.php");
	
	$obj=new MyDBClass;
	$row=$obj->displayReviews();
?>
	<table>
		<thead>
			<th>Name. </th>
			<th>Email. </th>
			<th>Message. </th>
		</thead>
		
<?php
	while($res=mysqli_fetch_array($row))
	{
		echo  "<tr><td>".$res['name']."</td><td>".$res['email']."</td><td>".$res['message']."</td></tr>";
	}
?>
	
	</table>