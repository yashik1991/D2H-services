<?php include("header.php");?>
			<div id="page-wrapper">
				<div class="graphs">
					
						<div class="tab-content">
						<div class="tab-pane active" id="horizontal-form">
						<script>
	function validation()
	{
		a=document.getElementById("img");
		b=document.getElementById("package");
		c=document.getElementById("cost");
		x=document.getElementById("cat");
		y=document.getElementById("dur");
		z=document.getElementById("err");
		if(a.value=="")
		{
			z.style.display="block";
			return false;
		}
		if(b.value=="")
		{
			z.style.display="block";
			return false;
		}
		if(c.value=="")
		{
			z.style.display="block";
			return false;
		}
		if(x.value=="")
		{
			z.style.display="block";
			return false;
		}
		if(y.value=="")
		{
			z.style.display="block";
			return false;
		}
		return true;
	}
	</script>
							<form method="post" class="form-horizontal" action="#" enctype="multipart/form-data">
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Images</label>
									<div class="col-sm-8">
										<input type="file" class="form-control1" name="imgupload" id="img" placeholder="">
									</div>
								</div>

								<div class="form-group">
									<label for="disabledinput" class="col-sm-2 control-label" >Name</label>
									<div class="col-sm-8">
										<input disabled="text" type="text" class="form-control1" name="name" placeholder="Add package" id="package" placeholder="">
									</div>
								</div>
								<div class="form-group">
									<label for="inputPassword" class="col-sm-2 control-label">Cost</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" name="cost" placeholder="Add Cost" id="cost">
									</div>
								</div>
								<div class="form-group">
									<label for="inputPassword" class="col-sm-2 control-label">Category</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1"  name="category" id="cat" placeholder="Add Category">
									</div>
								</div>
								<div class="form-group">
									<label for="inputPassword" class="col-sm-2 control-label">Duration</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" name="duration" id="dur" placeholder="Add duration.(in months)">
									</div>
								</div>
								<!--div class="form-group">
									<label for="txtarea1" class="col-sm-2 control-label">Category</label>
									<div class="col-sm-8"><textarea name="txtarea1"  name="category" id="cat" placeholder="Add Category cols="50" rows="4" class="form-control1"></textarea></div>
								</div>
								<div class="form-group">
									<label for="txtarea1" class="col-sm-2 control-label">Duration</label>
									<div class="col-sm-8"><textarea name="txtarea1" id="txtarea1" cols="50" rows="4" class="form-control1"></textarea></div>
								</div-->
									
								
    
						</div>
 
						<div class="bs-example" data-example-id="form-validation-states-with-icons">
						
						  <div class="panel-footer">
							<div class="row">
								<div class="col-sm-8 col-sm-offset-2">
								<Span style="border:solid 2px red; color:red; padding:10px; display:none;" id="err">please Enter Required Fields.</span>
									<button class="btn-success btn" onclick="return validation();">Submit</button>
									
									<button class="btn-inverse btn">Reset</button>
								</div>
							</div>
						 </div>
						
					  </div>
					  </form>
				</div>
			</div>
		</div>
		<?php include("footer.php");?>