<?php
	include("header.php");
	$row=displayPackages();
	
	if($row !=null)
	{
	?>
	<div class="bs-example4" data-example-id="contextual-table">
						<table class="table">
						  <thead>
							<tr>
								<th>Image.</th>
								<th>Name.</th>
								<th>Cost.</th>
								<th>Duration.</th>
								<th>Category.</th>
								<th colspan="2">Operation</th>
							</tr>
						  </thead>
						  <tbody>
							<tr class="active">
	<?php
		while($res=mysqli_fetch_array($row))
		{
			echo "
					<td><a href='".$res["picsource"]."'><img src='".$res['picsource']."' height='100' width='100'/></td>
					<td>".$res['name']."</td>
					<td>".$res['cost']."</td>
					<td>".$res['duration']."</td>
					<td>".$res['category']."</td>
					<td><a href='editPackage.php?id=".$res["id"]."&name=".$res["name"]."&cost=".$res["cost"]."&category=".$res["category"]."&duration=".$res["duration"]."&picsource=".$res["picsource"]."'>Edit</a></td>
					<td><a href='editPackageController.php?msg=del&name=".$res['name']."'>Delete.</a></td>
				 </tr>";
		}
	}
	
?>
						</tbody>
					</table>
	</div>
<?php
	
	include("footer.php");
?>