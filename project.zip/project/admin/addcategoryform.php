<?php include("header.php");?>
			<div id="page-wrapper">
				<div class="graphs">
					
						<div class="tab-content">
						<div class="tab-pane active" id="horizontal-form">
						<script>
	function validation()
	{
		x=document.getElementById("cat");
		z=document.getElementById("err");
		if(x.value=="")
		{
			z.style.display="block";
			return false;
		}		
		return true;
	}
	</script>
							<form method="post" class="form-horizontal" action="add_category_controller.php">
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Categories</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" id="cat"  placeholder="Add Category">
										
									</div>
								</div>
								</div>
 
						<div class="bs-example" data-example-id="form-validation-states-with-icons">
						
						  <div class="panel-footer">
							<div class="row">
								<div class="col-sm-8 col-sm-offset-2">
								<Span style="border:solid 2px red; color:red; padding:10px; display:none;" id="err">please Enter Required Categorie.</span>
									<button class="btn-success btn"  value="Add Channel Categories" onclick="return validation();">Submit</button>
									
									<button class="btn-inverse btn">Reset</button>
								</div>
							</div>
						 </div>
						
					  </div>
					  </form>
				</div>
			</div>
		</div>
		<?php include("footer.php");?>