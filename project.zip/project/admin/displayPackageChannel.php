
<?php
	include("header.php");
?>
			<div id="page-wrapper">
				<div class="graphs">
					<div class="col_3">
						<div class="col-md-3 widget widget1" style="width:100%;">
<?php
						$row=displayPackages();
						while($res=mysqli_fetch_array($row))
						{
							echo "<div class='r3_counter_box' style='width:23.5%;float:left;margin: 10px;'>
								<i class='fa fa-mail-forward'></i>
								<div class='stats'><a href='packsChannel.php?packId=".$res['id']."'>
								  ".$res['name']."
									</a>
								  <div class='grow'>
									<p>Package</p>
								  </div>
								</div>
							</div>";
						}
?>
						</div>
						<!--<div class="clearfix"> </div>-->
					</div>

			<!-- switches -->

		<!-- //switches -->
		
<?php
	include("footer.php");
?>