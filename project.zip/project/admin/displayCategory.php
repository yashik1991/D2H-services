<?php
	include("header.php");
	$row=displayCategory();
	
	if($row !=null)
	{
	?>
	<div class="bs-example4" data-example-id="contextual-table">
						<table class="table">
						  <thead>
							<tr>
							  <th>#</th>
							  <th>Name.</th>
							  <th colspan="3">Operations.</th>
							</tr>
						  </thead>
						  <tbody>
							
	<?php
		while($res=mysqli_fetch_array($row))
		{
			echo "<tr class='active'>
					<td>".$res['id']."</td>
					<td>".$res['name']."</td>
					<td><a href='editCategory.php?category=".$res["name"]."&id=".$res["id"]."'>Edit</a></td>
					<td><a href='editcontroller.php?msg=del&category=".$res['name']."'>Delete</a></td>
				 </tr>";
		}
	}
	
?>
						</tbody>
					</table>
	</div>
<?php
	
	include("footer.php");
?>