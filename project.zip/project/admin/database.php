<?php
	class database
	{
		public function connection()
		{
			$con=mysqli_connect("localhost","root","","d2hproject");
			return $con;
		}
	}
		function displayCategory()
		{
			$conobj=new database();
			$con=$conobj->connection();
			$query="select * from category";
			$res=mysqli_query($con,"$query");
			
			return $res;
		}
		function displayChannels()
		{
			$conobj=new database();
			$con=$conobj->connection();
			$query="select * from channel";
			$res=mysqli_query($con,"$query");
			
			return $res;
		}
		function displayPackages()
		{
			$conobj=new database();
			$con=$conobj->connection();
			$query="select * from package";
			$res=mysqli_query($con,"$query");
			
			return $res;
		}
		function displayPackage($name)
		{
			$conobj=new database();
			$con=$conobj->connection();
			$query="select * from package where name='$name'";
			$res=mysqli_query($con,"$query");
			
			return $res;
		}
		function updatePackage($cost,$duration,$cat,$folder,$id)
		{
			$conobj=new database();
			$con=$conobj->connection();
			$query="update package set cost='$cost',duration='$duration',category='$cat',picsource='$folder' where id='$id'";
			$res=mysqli_query($con,"$query");
			
			return $res;
		}
		function updateCategory($name,$id)
		{
			$conobj=new database();
			$con=$conobj->connection();
			$query="update category set name='$name' where id='$id'";
			$res=mysqli_query($con,"$query");
			
			return $res;
		}
		function deleteCategory($name)
		{
			$conobj=new database();
			$con=$conobj->connection();
			$query="delete from category where name='$name'";
			$res=mysqli_query($con,"$query");
			
			return $res;
		}
		function sign_in($user,$pass)
		{
			$conobj=new database();
			$con=$conobj->connection();
			$query="select * from admin_details where username='$user' and password='$pass'";
			$res=mysqli_query($con,"$query");
			
			return $res;
		}
		function add_category($cat)
		{
			$conobj=new database();
			$con=$conobj->connection();
			$query="insert into category(name) values('$cat')";
			$res=mysqli_query($con,"$query");
			
			return $res;
		}
		function packs_wise_channels($pid,$chid)
		{
			$conobj=new database();
			$con=$conobj->connection();
			$query="insert into packs_wise_channels(pid,cid) values('$pid','$chid')";
			$res=mysqli_query($con,"$query");
			
			return $res;
		}
		function add_package($name,$cost,$folder,$duration,$cat)
		{
			$conobj=new database();
			$con=$conobj->connection();
			$query="insert into package(name,cost,picsource,duration,category) values('$name','$cost','$folder','$duration','$cat')";
			$res=mysqli_query($con,"$query");
			
			return $res;
		}
		function displaypacks_wise_channels()
		{
			$conobj=new database();
			$con=$conobj->connection();
			$query="select packs_wise_channels(pid,cid) values('$pid','$chid')";
			$res=mysqli_query($con,"$query");
			
			return $res;
		}
		function displaySettopbox()
		{
			
			$conobj=new database();
			$con=$conobj->connection();
			$query="select * from settopbox";
			$res=mysqli_query($con,"$query");
			
			return $res;
		}
		function deletepackage($name)
		{
			$conobj=new database();
			$con=$conobj->connection();
			$query="delete from package where name='$name'";
			$res=mysqli_query($con,"$query");
			
			return $res;
		}
?>