<?php
	include("database.php");
	
		$tot=$_POST["total"];
		$pid=$_GET['name'];
		
		for($i=1; $i<$tot; $i++)
		{
			if(isset($_POST["name".$i]))
			{
				$chid=$_POST["name".$i];
				
				$res=packs_wise_channels($pid,$chid);
			}
		}
		header("location:pack_with_channel.php?msg=channelAdded");
	session_start();
	if(isset($_SESSION['sess']))
	{
		
	}

?>