<?php 
	include("database.php");
	session_start();
	if(!isset($_SESSION['sess']))
	{
		header("location:index.php?msg=plz_login_first");
	}
?>
<html>
	<head>
	<script>
		function packageListner()
		{
			var x=document.getElementById("packs");
			window.location.href="pack_with_channel.php?packs="+x.value;
		}
		function empty()
		{
			var a=document.getElementById('chkBox');
				z=document.getElementById("err");
			if(a.value)
			{
				return true;
			}
			else
			{ 
				z.style.display="block";
				return false;
			}	
		}
	</script>
	</head>
	<body>
		<select name="packs" id="packs" onchange="packageListner();">
		<option>--select Pack first--</option>
		<?php
			include("database.php");
			
			$row=displayPackages();
			while($res=mysqli_fetch_array($row))
			{
				$pid=$_GET['id'];
				echo "<option ";
		?>
		<?php
				if(isset($_GET['packs']))
				{
					if($res['name']==$_GET['packs'])
						{
							echo "selected";
						}
				}
				echo">".$res['name']."</option>";
			}
		?>
		</select>
		<?php 
			if(isset($_GET['packs']))
			{
		?>
		<table>
			<tr>
				<th>Name.</th>
				<th>Cost.</th>
				<th>Duration.</th>
				<th>Image.</th>
			</tr>
			<tr>
			<?php
				if(isset($_GET['packs']))
				{
					$name=$_GET['packs'];
					$row=displayPackage($name);
				
					while($res=mysqli_fetch_array($row))
					{
						$pid=$res['id'];
					echo "<td style='margin:10px;'>".$res['name']."</td>
						<td style='margin:10px;'>".$res['cost']."</td>
						<td style='margin:10px;'>".$res['duration']."</td>
						<td style='margin:10px;'><img src='".$res['picsource']."' height='100' width='100'/></td>";
					}
				}
			?>
			</tr>
		</table>
		<hr/><hr/>
		<form method="post" action="pack_with_channelController.php?name=<?php echo $pid;?>">
		
		<table>
			<tr>
				<th>Image</th>
				<th>Name</th>
				<th>Select</th>
			</tr>
			
			<?php
				//$name=$_GET['packs'];
				$row=displayChannels();
				$i=1;
				while($res=mysqli_fetch_array($row))
				{
					echo "<tr>
						<td><img src='".$res['imgsource']."' height='80' width='80'/></td> 
						<td>".$res['name']."</td>
						<td><input type='checkbox' name='name".$i."' id='chkBox' value='".$res['id']."'/></td>
						</tr>";
						$i++;
				}
			?>
			
		</table>
		<Span style="border:solid 2px red; color:red; padding:10px; display:none;" id="err">please Enter Required Fields.</span>
			<input type="hidden" name="total" value="<?php echo $i; ?>"/>
			<input type="submit" name="addChannel" id="addChannel" value="AddChannelsIntoPack" onclick="return empty();"/>
			<a href="home.php">Home</a>
		</form>
		<?php
			}
		?>
	</body>
</html>