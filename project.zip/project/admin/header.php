<?php
	$title="Dashboard";
	
	include("database.php");
	session_start();
	if(!isset($_SESSION['sess']))
	{
		header("location:index.php?msg=plz_login_first");
	}
?>

<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title><?php echo "$title"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Easy Admin Panel Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<!-- //lined-icons -->
<!-- chart -->
<script src="js/Chart.js"></script>
<!-- //chart -->
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>2
<!--//end-animate-->
<!----webfonts--->
<link href='http//fonts.googleapis.com/css?family=Cabin:400,400italic,500,500italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<!---//webfonts---> 
 <!-- Meters graphs -->
<script src="js/jquery-1.10.2.min.js"></script>
<!-- Placed js at the end of the document so the pages load faster -->
<script>
		function packageListner()
		{
			var x=document.getElementById("packs");
			window.location.href="pack_with_channel.php?packs="+x.value;
		}
	
	</script>

</head> 
   
 <body class="sticky-header left-side-collapsed"  onload="initMap()">
    <section>
				
    <!-- left side start-->
		<div class="left-side sticky-left-side">

			<!--logo and iconic logo start-->
			<div class="logo">
				<h1><a href="#">Easy <span>Admin</span></a></h1>
			</div>
			<div class="logo-icon text-center">
				<a href="index.php"><i class="lnr lnr-home"></i> </a>
			</div>

			<!--logo and iconic logo end-->
			<div class="left-side-inner">

				<!--sidebar nav start-->
					<ul class="nav nav-pills nav-stacked custom-nav">
						<li class="active"><a href="home.php"><i class="glyphicon glyphicon-home""></i><span >Dashboard</span></a></li>
						
							<li><a href="displayCategory.php"><i  class="glyphicon glyphicon-envelope"></i><span>Category</span></a>
									<ul class="sub-menu-list">
									<li><a href="add_category.php">Add Category.</a> </li>
									</ul>
							</li>
						
						<li><a href="channel.php"><i  class="glyphicon glyphicon-book"></i> <span>Channel.</span></a>
							<ul class="sub-menu-list">
								<li><a href="addChannels.php">Add Channels.</a> </li>
								<li><a href="channel.php">Available Channels.</a></li>
							</ul>
						</li>
						<li class="menu-list"><a href="displaysetbox.php"><i class="glyphicon glyphicon-hdd"></i> <span>SetTopBox</span></a>
							<ul class="sub-menu-list">
								<li><a href="displaysetbox.php">Display SetTopBox</a> </li>
								<li><a href="add_set_top_box.php">Add SetTopBox.</a></li>
							</ul>
						</li> 
						<li><a href="products.php"><i  class="glyphicon glyphicon-shopping-cart"></i> <span>Add Products.</span></a></li>              
						<li class="menu-list"><a href="packages.php"><i class="glyphicon glyphicon-gift"></i> <span>Packages</span></a>
							<ul class="sub-menu-list">
								<li><a href="packages.php">Display Packages</a> </li>
								<li><a href="add_package.php">Add Package.</a></li>
								<li><a href="pack_with_channel.php">Add Channel Into Package.</a></li>
							</ul>
						</li>      
						<li><a href="review.php"><i class="lnr lnr-book"></i> <span>Reviws</span></a></li>
						<li><a href="media.php"><i class="lnr lnr-select"></i> <span>Media Css</span></a></li>
					</ul>
				<!--sidebar nav end-->
			</div>
		</div>
		<!-- left side end-->
		
    
		<!-- main content start-->
		<div class="main-content">
			<!-- header-starts -->
			<div class="header-section">
			 
			<!--toggle button start-->
			<a class="toggle-btn  menu-collapsed"><i class="fa fa-bars"></i></a>
			<span class="user-name"><a href="#"><?php echo "Welocome ".$_SESSION['sess'].".";?></a></span>
			<!--toggle button end-->
								<div class="profile_details">	
									
						<ul>
							<li class="dropdown profile_details_drop">
								<a href="logout.php" >
										<?php
											if(isset($_SESSION['sess']))
											{
										?>
										<div class="user-name">
											<p>Logout</p>
										 </div>
											<?php
											}
										 ?>
										<div class="clearfix"></div>	
									
								</a>
								
							</li>
							<div class="clearfix"> </div>
						</ul>
					</div>		
	
			</div>
			
		<!-- //header-ends -->