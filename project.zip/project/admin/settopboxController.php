<?php
	include("database.php");
	include('MyDBClass.php');
	if(isset($_POST['name']) && isset($_POST['cost']) && isset($_FILES['imgupload']))
	{
		if(($_POST['name']!="") && ($_POST['cost']!=""))
		{
			$name=$_POST['name'];
			$cost=$_POST['cost'];
			$filename=$_FILES['imgupload']['name'];
			$tempname=$_FILES['imgupload']['tmp_name'];
			$folder="images/".$filename;
		
			move_uploaded_file($tempname,$folder);
			$obj=new MyDBClass;
			$res=$obj->add_settopbox($name,$cost,$folder);
	
			if($res>0)
			{
				header("location:add_set_top_box.php?msg=success");
			}
			else
			{
				header("location:add_set_top_box.php.php?msg=fail");
			}
		}
		
	}
	else
	{
		header("location:add_set_top_box.php.php?msg=fill_the_required_fields");
	}
	//add_settopbox
?>