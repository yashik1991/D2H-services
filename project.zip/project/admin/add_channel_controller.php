<?php
	include("database.php");
	include("MyDBClass.php");
	
	if(isset($_POST['name']) && isset($_POST['category']) && isset($_FILES['imgupload']))
	{
		if(($_POST['name']!="") && ($_POST['category']!="") )
		{
			$name=$_POST['name'];
			$cat=$_POST['category'];
			$filename=$_FILES['imgupload']['name'];
			$tempname=$_FILES['imgupload']['tmp_name'];
			$folder="images/".$filename;		
			move_uploaded_file($tempname,$folder);
			
			$obj=new MyDBClass;
			$res=$obj->addChannels($name,$cat,$folder);
	
			if($res!=0)
			{
				header("location:addChannels.php?msg=success");
			}
			else
			{
				header("location:addChannels.php?msg=fail");
			}
		}
		
	}
	else
	{
		header("location:addChannels.php?msg=fill_the_required_fields");
	}
?>