
<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();

	include("header.php");
?>
			<div id="page-wrapper">
				<div class="graphs">
					<div class="col_3">
						<div class="col-md-3 widget widget1">
							<div class="r3_counter_box">
								<i class="fa fa-mail-forward"></i>
								<div class="stats">
								  <h5><?php 
											$row=displayPackages();
											$res=mysqli_num_rows($row);
								  
											echo $res; 
										?>
									</h5>
								  <div class="grow">
									<p>Packages</p>
								  </div>
								</div>
							</div>
						</div>
						<div class="col-md-3 widget widget1">
							<div class="r3_counter_box">
								<i class="fa fa-users"></i>
								<div class="stats">
								  <h5><?php 
											$row=displayChannels();
											$res=mysqli_num_rows($row);
								  
											echo $res; 
										?>								  
								  </h5>
								  <div class="grow grow1">
									<p>Channels</p>
								  </div>
								</div>
							</div>
						</div>
						<div class="col-md-3 widget widget1">
							<div class="r3_counter_box">
								<i class="fa fa-eye"></i>
								<div class="stats">
								  <h5><?php 
											$row=displayCategory();
											$res=mysqli_num_rows($row);
								  
											echo $res; 
										?></h5>
								  <div class="grow grow3">
									<p>Category</p>
								  </div>
								</div>
							</div>
						 </div>
						 <div class="col-md-3 widget">
							<div class="r3_counter_box">
								<i class="fa fa-usd"></i>
								<div class="stats">
								  <h5>70 <span>%</span></h5>
								  <div class="grow grow2">
									<p>Profit</p>
								  </div>
								</div>
							</div>
						</div>
						<div class="clearfix"> </div>
					</div>

			<!-- switches -->

		<!-- //switches -->
		
<?php
	include("footer.php");
}

?>