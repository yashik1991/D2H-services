<?php include("header.php");
		$cat=$_GET['category'];
		$id=$_GET['id'];
?>
			<div id="page-wrapper">
				<div class="graphs">
					
						<div class="tab-content">
						<div class="tab-pane active" id="horizontal-form">
						<script>
	function validation()
	{
		x=document.getElementById("cat");
		z=document.getElementById("err");
		if(x.value=="")
		{
			z.style.display="block";
			return false;
		}		
		return true;
	}
	</script>
							<form class="form-horizontal" method="post" action="editcontroller.php?msg=update">
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Category</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1"  id="categories" name="categories" placeholder="Add Category"  value="<?php echo $cat;?>">
									</div>
								</div>
								<!--new-->
								<input type="hidden" name="id" value="<?php echo $id;?>"/>
								<!--new-->
								<div class="form-group">
									<label for="disabledinput" class="col-sm-2 control-label"></label>
									<div class="col-sm-8">
										<input type="hidden"  class="form-control1" name="id" value="<?php echo $id;?>">
									</div>
								</div>

						<div class="bs-example" data-example-id="form-validation-states-with-icons">
						
						  <div class="panel-footer">
							<div class="row">
								<div class="col-sm-8 col-sm-offset-2">
								<Span style="border:solid 2px red; color:red; padding:10px; display:none;" id="err">please Enter Required Categorie.</span>
									<button class="btn-success btn" name="submit"   value="Edit Category" onclick="return validation();"/>Edit Category</button>
		
									
									<button class="btn-inverse btn">Reset</button>
								</div>
							</div>
						 </div>
						
					  </div>
					  </form>
				</div>
			</div>
		</div>
<?php include("footer.php");?>