<?php include("header.php");?>
			<div id="page-wrapper">
				<div class="graphs">
					
						<div class="tab-content">
						<div class="tab-pane active" id="horizontal-form">
							<form class="form-horizontal">
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Images</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" id="focusedinput" placeholder="Add Category">
									</div>
								</div>
								</div>
 
						<div class="bs-example" data-example-id="form-validation-states-with-icons">
						
						  <div class="panel-footer">
							<div class="row">
								<div class="col-sm-8 col-sm-offset-2">
									<button class="btn-success btn">Submit</button>
									
									<button class="btn-inverse btn">Reset</button>
								</div>
							</div>
						 </div>
						
					  </div>
					  </form>
				</div>
			</div>
		</div>
		<?php include("footer.php");?>