<?php
	$title="EditPackage";
	include("header.php");
		
	$user=$_GET['name'];
	$cost=$_GET['cost'];
	$src=$_GET['picsource'];
	$category=$_GET['category'];
	$dur=$_GET['duration'];
	$id=$_GET['id'];
	

	ye type dikh ra h konsa img ka ai kya hai file hai to iski value me file ani chaye or tu daal raha hai string to krueske  fer agr m isse text kr du to abe to vaha se new file kese uthayega ha yahi to m kahra prhnb ltm ahbho ij etgio  maeg br ata raha hua
	//sie mitayo mat jo kh ra hu vo smajh liyo
	//1)ek hidden field me  img ka path daal liyp purane vala
	//2) fir bus terko ek kam or karna hai jab data submit ho or controller pe jae tab tune check karana hai ki jo file walla input hai vo 
	//khali hai ya koi new image dali hai admin  ne 
	//3)agar new image vala input khali nahi hai to new image ka path jaye update ki query me nahi too 
	//4)jo path hidden field me hai vo update ki query me jaye 
	//bus ye karna hai ab thoda soch le okk bai.. ...hmm
?>
<html>
	<head>
	</head>
	<body>
		<form method="post" action="editPackageController.php?msg=update" enctype="multipart/form-data">
			<input type="hidden" name="id" value="<?php echo $id;?>"/>
			Image.<input type="file" name="imgupload" value="<?php echo $src;?>"><br/>
			Name<input type="text" name="name" disabled="disabled" value="<?php echo $user;?>"/><br/>
			Cost<input type="text" name="cost"  value="<?php echo $cost;?>"/><br/>
			Category<input type="text" name="category"  value="<?php echo $category;?>"/><br/>
			Duration<input type="text" name="duration"  value="<?php echo $dur;?>"/><br/>
			<input type="submit" name='submit' value="Edit Package"/>
		</form>
	</body>
</html>
<?php
	include("footer.php");
	
?>