<?php
	include("database.php");
	
	if(isset($_POST['name']) && isset($_POST['cost']) && isset($_POST['category']) && isset($_POST['duration']) && isset($_FILES['imgupload']))
	{
		if(($_POST['name']!="") && ($_POST['cost']!="") && ($_POST['category']!="") && ($_POST['duration']!=""))
		{
			$name=$_POST['name'];
			$cost=$_POST['cost'];
			$cat=$_POST['category'];
			$duration=$_POST['duration'];
			$filename=$_FILES['imgupload']['name'];
			$tempname=$_FILES['imgupload']['tmp_name'];
			$folder="images/".$filename;
		
			move_uploaded_file($tempname,$folder);
			$res=add_package($name,$cost,$folder,$duration,$cat);
	
			if($res>0)
			{
				header("location:add_package.php?msg=success");
			}
			else
			{
				header("location:add_package.php?msg=fail");
			}
		}
		
	}
	else
	{
		header("location:add_package.php?msg=fill_the_required_fields");
	}
?>