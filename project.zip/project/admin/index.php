<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
	$title="Admin login";
?>
<!DOCTYPE HTML>
<html>
<head>
<title><?php echo "$title";?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Easy Admin Panel Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<!-- //lined-icons -->
<!-- chart -->
<script src="js/Chart.js"></script>
<!-- //chart -->
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
	<script>
	function validation()
	{
		x=document.getElementById("username");
		y=document.getElementById("password");
		z=document.getElementById("err");
		if(x.value=="")
		{
			z.style.display="block";
			return false;
		}
		if(y.value=="")
		{
			z.style.display="block";
			return false;
		}
		return true;
	}
	</script>    
<!----webfonts--->
<link href='//fonts.googleapis.com/css?family=Cabin:400,400italic,500,500italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<!---//webfonts---> 
 <!-- Meters graphs -->
<script src="js/jquery-1.10.2.min.js"></script>
<!-- Placed js at the end of the document so the pages load faster -->

</head> 
   
 <body class="sign-in-up">
    <section>
			<div id="page-wrapper" class="sign-in-wrapper" style="background-color:#eee;">
				<div class="graphs">
					<div class="sign-in-form" style="background-color:grey;">
						<div class="sign-in-form-top">
							<p><span>Sign In to</span> <a href="#">Admin</a></p>
						</div>
						<div class="signin" >

							<form method="post" action="login.php">
							<div class="log-input">
								<div class="log-input-left">
								   <input type="text" class="user" value="" name="username" placeholder="Your Name" id="username" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email address:';}"/>
								</div>
								<!--<span class="checkbox2">
									 <label class="checkbox"><input type="checkbox" name="checkbox" checked=""><i> </i></label>
								</span>-->
								<div class="clearfix"> </div>
							</div>
							<div class="log-input">
								<div class="log-input-left">
								   <input type="password" class="lock" value="" name="password" placeholder="Password" id="password" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email address:';}"/>
								</div>
								<div class="clearfix"> </div>
							</div>
							<div class="log-input">
								<div class="log-input-left">
								   <input type="text" class="lock" name="err" value="please Enter username and password" id="err" disabled="disabled" style="display:none; color:red;" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email address:';}"/>
								</div>
								<div class="clearfix"> </div>
							</div>
								<!--Span style="border:solid 1px red; color:red;  display:none; max-width:400px; padding:10px;" id="err">please Enter username and password</span-->
								
							<?php
						
								if(isset($_GET["msg"]))
								{	
									
									if($_GET["msg"]=='invalid')
									{
										
								?>
										<!--Span style="border:solid 1px red; color:red; max-width:400px; padding:10px;">please Enter a valid username Or password</span-->
							<div class="log-input">
								<div class="log-input-left">
								   <input type="text" class="lock" value="please Enter username and password" style="border:solid 1px red; color:red;" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email address:';}"/>
								</div>
								<div class="clearfix"> </div>
							</div>
									
								<?php
									}
								}							
								?>
							<input type="submit" value="Login to your account"  onclick="return validation();" style="margin-top:20px; margin-bottom:20px;"/>
						</form>	 
						</div>
					</div>
				</div>
			</div>
	</section>
	
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
</body>
</html>		
