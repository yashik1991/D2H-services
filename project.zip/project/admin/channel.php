<?php
	include("header.php");
?>
<div class="form-check" >
<?php
	include("MyDBClass.php");
	$obj=new MyDBClass;
	$row=$obj->displaychannels();
	while($res=mysqli_fetch_array($row))
	{
		echo "<div style='float:left; margin:10px; padding:10px;'><img src='".$res['imgsource']."'width=150px height=150px class='shadow-lg p-3 mb-5 bg-white rounded'/><br/>".$res['name']."<br/></div>"; 	
	}
?>
<label class="form-check-label" for="exampleCheck1"></label>
</div>
<div style="clear:both;"></div>
<?php
	include("footer.php");
?>