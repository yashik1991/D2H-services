<?php
	$title="Add Channels.";
	include("header.php");
?>
<div id="page-wrapper">
				<div class="graphs">
					
						<div class="tab-content">
						<div class="tab-pane active" id="horizontal-form">
	

	<script>
	function validation()
	{
		a=document.getElementById("img");
		b=document.getElementById("channel");
		x=document.getElementById("cat");
		z=document.getElementById("err");
		if(a.value=="")
		{
			z.style.display="block";
			return false;
		}
		if(b.value=="")
		{
			z.style.display="block";
			return false;
		}
		if(x.value=="")
		{
			z.style.display="block";
			return false;
		}
		return true;
	}
	</script>
	</head>
	<body>
	<!--div style="height:300px;  width:300px; border:1px solid red; margin-left:380px; margin-top:90px; padding-left:20px; padding-top:20px;"-->
		<form method="post" action="add_channel_controller.php" enctype="multipart/form-data">
          <div class="form-group">
           									<label for="focusedinput" class="col-sm-2 control-label">Images</label>
									<div class="col-sm-8">
			<input type="file"  class="form-control1" name="imgupload" id="img">
			</div><br/><br/>
								</div><br/><br/>
											<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label" >Name</label>
									<div class="col-sm-8">
                 
		<input type="text" name="name" class="form-control1" placeholder="Add Channel Name" id="channel"/><br/><br/>
		</div><br/><br/>
								</div><br/><br/>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label" >Category</label>
									<div class="col-sm-8">
										<select name="category" class="form-control1">
			</div><br/><br/>
								</div><br/><br/>
						
						<?php
									$row=displayCategory();
									while($res=mysqli_fetch_array($row))
									{
										echo "<option >".$res['name']."</option>";
									}
						
						?>
						
						
					</select><br/><br/>
			<Span style="border:solid 2px red; color:red; padding:10px; display:none;" id="err">please Enter Required Fields.</span><br/><br/>
			<!--a href="packages.php">Display</a-->
												<a class="btn-success btn" href="packages.php">Display</a>
			<input type="submit" name="submit" value="Add Channels" class="btn-success btn" onclick=" return validation();" />
			</div>
		</form>
		
	
	</body>
</html>
<?php
	include("footer.php");
?>
