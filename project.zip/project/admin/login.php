<?php
	include("database.php");
	/*class database
	{
		function connection()
		{
			$con=mysqli_connect("localhost","root","","admin_detail");
			return $con;
		}
		function sign_in($user,$pass)
		{
			$con=connection();
			$query="select * from admin_details where username='$user' && password='$pass'";
			$res=mysqli_query($con,$query);
		
			return $res;
		}
	}*/
	
	if(isset($_POST['username']) && isset($_POST['password']))
	{
	
	if(($_POST['username'] !="") && ($_POST['password']!=""))
	{
		$user=$_POST['username'];
		$pass=$_POST['password'];
	
		$row=sign_in($user,$pass);
		$res=mysqli_fetch_array($row);
	
	
		if($res!="")
		{
			session_start();
			$_SESSION["sess"]=$user;
			header("location:home.php");
		}
		else
		{
			header("location:index.php?msg=invalid");
		}
	}
	else
	{
		header("location:index.php?msg=required_fields");
	}
	}
?>