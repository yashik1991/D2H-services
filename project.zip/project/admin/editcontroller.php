<?php
include("database.php");
if(isset($_GET['msg']))
	{
		if($_GET['msg']=='del')
		{
			$name=$_GET['category'];
			$res=deleteCategory($name);
			if($res>0)
			{
				header("location:displayCategory.php?msg=upsuccess");
			}
		}
		if($_GET['msg']=='update')
		{
			if(isset($_POST['submit']))
			{
				$name=$_POST['categories'];
				$id=$_POST['id'];
						
				$res=updateCategory($name,$id);
				if($res>0)
				{
					header("location:displayCategory.php?msg=upsuccess");
				}
			
			}
		}
	}
	
?>