<?php
	include("header.php");
	include('MyDBClass.php');
	
	$obj=new MyDBClass;
	$row=displaySettopbox();
	
	if($row !=null)
	{
	?>
	<div class="bs-example4" data-example-id="contextual-table">
						<table class="table">
						  <thead>
							<tr>
								<th>Image.</th>
								<th>Name.</th>
								<th>Cost.</th>
								<th colspan="2">Operation</th>
							</tr>
						  </thead>
						  <tbody>
							
	<?php
		while($res=mysqli_fetch_array($row))
		{
			echo "<tr class='active'>
					<td><a href='".$res["picsource"]."'><img src='".$res['picsource']."' height='100' width='100'/></td>
					<td>".$res['name']."</td>
					<td>".$res['cost']."</td>
					<td><a hef='#'>Edit</a></td>
					<td><a href='#?msg=del&name=".$res['name']."'>Delete.</a></td>
				 </tr>";
		}
	}
	
?>
						</tbody>
					</table>
	</div>
<?php
	
	include("footer.php");
?>