<?php
	include("database.php");
	
	if(isset($_POST['categories']))
	{
		$name=$_POST['categories'];
	
		$res=add_category($name);
	
		if($res>0)
		{
			
			header("location:add_category.php?msg=success");
		}
		else
		{
			header("location:add_category.php?msg=fail_to_add");
		}
	}
	else
	{
		header("location:add_category.php?msg=fill_required_fields");
	}
?>