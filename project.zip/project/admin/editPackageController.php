<?php
include("database.php");
if(isset($_GET['msg']))
	{
		if($_GET['msg']=='del')
		{
			$name=$_GET['name'];
			$res=deletepackage($name);
			if($res>0)
			{
				header("location:packages.php?msg=delsuccess");
			}
		}
		if($_GET['msg']=='update')
		{
			if(isset($_POST['submit']))
			{
				$id=$_POST['id'];
				//$name=$_POST['name'];
				$cost=$_POST['cost'];
				$duration=$_POST['duration'];
				$cat=$_POST['category'];
				$filename=$_FILES['imgupload']['name'];
				$folder="images/".$filename;
				
						
				$res=updatePackage($cost,$duration,$cat,$folder,$id);
				if($res>0)
				{
					header("location:packages.php?msg=upsuccess");
				}
			
			}
		}
	}
	
?>