<nav class="fh5co-nav" role="navigation" style="background-color:rgba(0,0,0,0.7);">
		<div class="container">
			<div class="row">
				<div class="left-menu text-right menu-1">
					<ul>
						<li><a href="work.html">Home</a></li>
						<li><a href="about.html">Set-Top</a></li>
						<li class="has-dropdown">
							<a href="services.html">Packs & Channels</a>
							<ul class="dropdown">
								<li><a href="#">Set-Top</a></li>
								<li><a href="#">Packs & Channels</a></li>
								<li><a href="#">Services</a></li>
								<li><a href="#">Channel Guide</a></li>
								<li><a href="#">Multi-TV</a></li>
								<li><a href="#">Offers</a></li>
							</ul>
						</li>
					</ul>
				</div>
				<div class="logo text-center">
					<div id="fh5co-logo"><a href="index.html">D2H services</a></div>
				</div>
				<div class="right-menu text-left menu-1">
					<ul>
						<li><a href="login.php">Login</a></li>
						<li class="has-dropdown">
							<a href="signup.php">Sign Up</a>
							<!--ul class="dropdown">
								<li><a href="#">HTML5</a></li>
								<li><a href="#">CSS3</a></li>
								<li><a href="#">Sass</a></li>
								<li><a href="#">jQuery</a></li>
							</ul-->
						</li>
						<li><a href="contact.html">Customer Care</a></li>
						<!-- <li class="btn-cta"><a href="#"><span>Login</span></a></li> -->
					</ul>
				</div>
			</div>
			
		</div>
	</nav>
