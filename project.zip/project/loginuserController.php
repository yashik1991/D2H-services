<?php
	include("MyDBClass.php");
	if(isset($_POST["nameText"]) && isset($_POST["passwordText"]))
	{
		$user=$_POST["nameText"];
		$pass=$_POST["passwordText"];

		$db=new MyDBClass;
		if($ret=$db->selectUserDetails($user,$pass))
		{
			if(isset($_POST["remember"]))
			{
				setcookie("Cookie",$user,time()+2000);
				session_start();
				$_SESSION["userSess"]=$user;
				header("location:index.php");
			}
			else
			{
				session_start();
				$_SESSION["userSess"]=$user;
				header("location:index.php");
			}
		}
		else
		{
			header("location:login.php?msg=invalid");
		}
	}
	else
	{
		header("location:signup.php");
	}
?>