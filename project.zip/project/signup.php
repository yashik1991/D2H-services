<!--!DOCTYPE html>
<html lang="en" dir="Itr">
<head>
<meta charset="utf-8">
<title>Sign up Form</title>
<link rel="stylesheet" href="signupcss.css">
</head>
<body>
<form class="box" action="#" method="post">
	
			
				
<h1>Signup Here</h1>

<!--signup form html-->


	
	<!--input type="text" placeholder="Enter First name" id="fnameText" name="">
	<input type="text" placeholder="Enter Last name" id="lnameText" name="">
	<input type="text" placeholder="Enter Address" id="addressText" name="">
	<input type="text" placeholder="Enter City" id="cityText" name="">
	<input type="text" placeholder="Enter State" id="stateText" name="">
	<input type="email" placeholder=" Enter Email" id="emailText" name="">
	<input type="password" placeholder="Enter New Password" id="passText" name="">
	<input type="password" placeholder="Confirm Password" id="confirmText" name="">
	<input type="submit" name="" value="SignUp">
	
</form-->



<!DOCTYPE html>
<html>
<head> 
<title>Signup form</title>
<link rel="stylesheet" href="demo.css" />
<!--style-->

.simple-form
{
	padding-left:470px;
    padding-top:1.5px;
	margin:auto 0px;
}
#registration
{
	width: 50%;
	background-color:#051019;
	opacity:0.8;
	padding:50px 8px;

}
h1{
	color:#fff;
}
#button
{
	width:250px;
	padding:5px;
	border-radius:5px;
	outline:0px;
	
}
#ph
{
	width:65px;
	padding:5px;
	border-radius:5px;
	outline:0px;
}
#phone
{
	width:180px;
	padding:5px;
	border-radius:5px;
	outline:0px;
}
#but{
	color:white;
	font-size:18px;
	
}
#butt{
	width:90px;
	padding:5px;
	border-radius:5px;
	outline:0px;
	background-color:#0c6996;
	color:aliceblue;
	font-size:18px;
}
#cp
{
	width:250px;
	padding:5px;
	border-radius:5px;
	outline:0px;
}

</style-->
</head>
<body style=background-image:url('images/bg2.jpg');>


<div class="simple-form">

<form method="post" action="signupuserController.php ">
<div class="signup">
<div class="signuph1"><h1>SignUp</h1></div>
<!--input type="text" name="fnameText" id="button" placeholder="Enter First Name"--><br><br>
<input type="text" name="nameText" id="button" placeholder="Enter Name"><br><br>
<input type="text" name="addressText" id="button" placeholder="Enter Address"><br><br>
<input type="text" name="cityText" id="button" placeholder="Enter City"><br><br>
<input type="text" name="stateText" id="button" placeholder="Enter State"><br><br>
<select id="ph"><option>+91</option><option>+92</option><option>+93</option></select>
<input type="number" name="phoneText" id="phone" placeholder="Enter Phone No."><br><br>
<input type="email" name="emailText" id="button" placeholder="Enter Email"><br><br>
<input type="radio" name="gender" id="rd"><span id="but">Male</span>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="gender"id="rd"><span id="but">FeMale</span><br><br>
<input type="password" name="passwordText" id="cp" placeholder="Enter Password"><br><br>
<!--input type="password" name="confirmpass" id="cp" placeholder="Confirm Password"-->
<div class="submit"><input type="submit" name="SignUp" id="butt">
</div>
</div>
</body>
</html>






