
<?php
class 
$servername = "localhost";
$username = "username";
$password = "";
$dbname = "D2hProject";

// Create connection
$conn = new mysqli_connect($fnameText, $lnameText,$cityText, $phoneText, $emailText $passText, $confirmText);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO register (fnameText, lnameText,cityText, emailText)
VALUES ('John', 'Doe', 'john@example.com')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>









?>