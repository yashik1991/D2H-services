<?php
class MyDBClass//dbmodel hai ye
{
	public $con,$com,$res;
	public function __construct()
	{
		$this->con=mysqli_connect("localhost","root","","d2hproject");// ye connection
	}
	public function insertUserDetails($name,$address,$city,$state,$phone,$email,$pass)
	{
		$query="insert into userdetails(name,address,city,state,phone,email,password) values('$name','$address','$city','$state','$phone','$email','$pass')";
		$this->com=mysqli_query($this->con,$query);
		if($this->com>0)		
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	public function updateUserDetails($name,$address,$city,$phone,$email,$state)
	{
		$query="update userdetails set name='$name', address='$address', city='$city', state='$state', phone='$phone' where email='$email'";
		$this->com=mysqli_query($this->con,$query);
		
		return $this->com;

	}
	public function deleteUserDetails($id)
	{
		$query="delete from userdetails where id='$id'";
		$this->com=mysqli_query($this->con,$query);
		if($row=mysqli_fetch_array($this->com))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	public function selectUserDetails($user,$pass)
	{
		$query="select * from userdetails where email='$user' and password='$pass'";
		$this->com=mysqli_query($this->con,$query);
		
		if($row=mysqli_fetch_array($this->com))
		{
			return $row['name'];
		}
	}
		
		public function displayPackages()
		{
			$query="select * from package";
			$this->com=mysqli_query($this->con,$query);
			
			return $this->com;
		}
		public function displayPackageChannels($pid)
		{
			$query="select * from channel join packs_wise_channels on packs_wise_channels.pid=(select pid from packs_wise_channels where id='$pid') and channel.id=packs_wise_channels.cid";
			$this->com=mysqli_query($this->con,$query);
			
			return $this->com;
		}
		public function selectPackage($pid)
		{
			$query="select * from package where id='$pid'";
			$this->com=mysqli_query($this->con,$query);
			
			return $this->com;
		}
		public function displayCategory()
		{
			$query="select * from package";
			$this->com=mysqli_query($this->con,$query);
			
			return $this->com;
		}
		public function displaychannels()
		{
			$query="select * from channel";
			$this->com=mysqli_query($this->con,$query);
			
			return $this->com;
		}
		public function displaysetTopboxs()
		{
			$query="select * from settopbox";
			$this->com=mysqli_query($this->con,$query);
			
			return $this->com;
		}
		public function displaySetTopbox($id)
		{
			$query="select * from settopbox where id='$id'";
			$this->com=mysqli_query($this->con,$query);
			
			return $this->com;
		}
		public function add_settopbox($name,$cost,$folder)
		{
			$query="insert into settopbox(name,cost,picsource) values($name,$cost,$folder)";
			$this->com=mysqli_query($this->con,$query);
			
			return $this->com;
		}
		public function customerCare($name,$email,$message)
		{
			$query="insert into customerCare(name,email,message) values('$name','$email','$message')";
			$this->com=mysqli_query($this->con,$query);
			
			return $this->com;
		}
		public function displayReviews()
		{
			$query="select * from  customerCare";
			$this->com=mysqli_query($this->con,$query);
			
			return $this->com;
		}
		public function displayProfile($user)
		{
			$query="select * from  userdetails where email='$user'";
			$this->com=mysqli_query($this->con,$query);
			
			return $this->com;
		}
		
		
}

?>