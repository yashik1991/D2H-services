<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <!--h2>Form control: select</h2>
  <p>The form below contains two dropdown menus (select lists):</p-->
  <form>
    <div class="form-group">
      <label for="sel1">Select list (select one):</label>
      <select class="form-control" id="sel1">
       <?php 
			include("MyDBClass.php");
			$obj=new MyDBClass;
			$row=$obj->displayPackages();
			while($res=mysqli_fetch_array($row))
			{
			echo "<option>". $res['name']."</option>";
			}
		?>
      </select>
      <br>
      </div>
  </form>
</div>

</body>
</html>
