
<!DOCTYPE html>
 <html>
<head>
<meta charset="utf-8">
<title>Login</title>

<link rel="stylesheet" href="logincss.css">
<script>
	function myFun()
	{
		x=document.getElementById("username");
		y=document.getElementById("passwd");
		z=document.getElementById("err");
		if(x.value=="")
		{
			z.style.display="block";
			return false;
		}
		if(x.value=="")
		{
			z.style.display="block";
			return false;
		}
		return true;
	}


</script>
</head>
<body style="background-image:url('images/bg2.jpg');">
<div class="loginBox">
<div class="glass">
<form  action="loginuserController.php" method="post" >

<img src="images/user.jpg" class="user">				
<h3>Login Here</h>

<!--login form html-->

<div class="inputBox">

	<input type="text" placeholder="Enter Username" id="username" name="nameText"/>
	<input type="Password" placeholder="Enter Password"  id="passwd" name="passwordText"/><br/>
	<input type="checkbox" style="margin-left:-250px;"   name="remember" id="remember"/>
	
	<label style="position:absolute;top:130px;left:40px;">Remember me</label>
	
	<input type="submit" name="" value="Login" onclick="return myFun()"/>
	<input type="text" value="please Enter username or password" style="border:solid 1px red; color:red;  display:none; max-width:400px; padding:1px;" id="err"/>

<a href="#">Forgot Password</a>
</div>
</form>

</div> 
</div>   
</body>
</html>