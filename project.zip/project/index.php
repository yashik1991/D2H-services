<?php	
	include("header.php");
?>


	<div id="fh5co-services" class="fh5co-bg-section">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-4">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i class="icon-eye"></i>
						</span>
						<h3>Retina Ready</h3>
						<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
					</div>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i class="icon-command"></i>
						</span>
						<h3>Fully Responsive</h3>
						<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
					</div>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i class="icon-mouse"></i>
						</span>
						<h3>Web Starter</h3>
						<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div id="fh5co-project">
		<div class="container">
			<div class="row animate-box" style="border-radius:10px;">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading" >
					<h2>Why D2H</h2>
					<p>Redefining the way to watch TV.See for yourself why our customer loves us.</p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4 col-sm-6 fh5co-project animate-box" data-animate-effect="fadeIn">
			
					<a href="#"><img src="images/india1.jpg" alt="Free HTML5 Website Template by FreeHTML5.co" class="img-responsive">
						<h3>Largest D2H Provider</h3>
						<span>With Crores of happy customers</span>
					</a>
				</div>
				<div class="col-md-4 col-sm-6 fh5co-project animate-box" data-animate-effect="fadeIn">
					<a href="#"><img src="images/24x7.jpg" alt="Free HTML5 Website Template by FreeHTML5.co" class="img-responsive">
						<h3>24x7</h3>
						<span>Customer Care</span>
					</a>
				</div>
				<div class="col-md-4 col-sm-6 fh5co-project animate-box" data-animate-effect="fadeIn">
					<a href="#"><img src="images/34.jpg" alt="Free HTML5 Website Template by FreeHTML5.co" class="img-responsive">
						<h3>Recording</h3>
						<span>Built in recording feature</span>
					</a>
				</div>
				<div class="col-md-4 col-sm-6 fh5co-project animate-box" data-animate-effect="fadeIn">
					<a href="#"><img src="images/claritytv1.jpeg" alt="Free HTML5 Website Template by FreeHTML5.co" class="img-responsive">
						<h3>HD Quality</h3>
						<span>Better picture and sound clarity</span>
					</a>
				</div>
				<div class="col-md-4 col-sm-6 fh5co-project animate-box" data-animate-effect="fadeIn">
					<a href="#"><img src="images/mobilepayments.jpg" alt="Free HTML5 Website Template by FreeHTML5.co" class="img-responsive">
						<h3>Recharge</h3>
						<span>Easy Recharge option</span>
					</a>
				</div>
				<!--div class="col-md-4 col-sm-6 fh5co-project animate-box" data-animate-effect="fadeIn">
					<a href="#"><img src="images/work-6.jpg" alt="Free HTML5 Website Template by FreeHTML5.co" class="img-responsive">
						<h3>Green Island</h3>
						<span>Branding</span>
					</a>
				</div-->

			</div>
		</div>
	</div>
	<div id="fh5co-testimonial" style="background-image:url(images/img_bg_1.jpg);">
		<div class="overlay"></div>
		<div class="container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
					<h2>Happy Clients</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="box-testimony animate-box">
						<blockquote>
							<span class="quote"><span><i class="icon-quote"></i></span></span>
							<p>&ldquo;Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.&rdquo;</p>
						</blockquote>
						<p class="author">John Doe, CEO <a href="http://freehtml5.co/" target="_blank">FREEHTML5.co</a> <span class="subtext">Creative Director</span></p>
					</div>
					
				</div>
				<div class="col-md-4">
					<div class="box-testimony animate-box">
						<blockquote>
							<span class="quote"><span><i class="icon-quote"></i></span></span>
							<p>&ldquo;Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.&rdquo;</p>
						</blockquote>
						<p class="author">John Doe, CEO <a href="http://freehtml5.co/" target="_blank">FREEHTML5.co</a> <span class="subtext">Creative Director</span></p>
					</div>
					
					
				</div>
				<div class="col-md-4">
					<div class="box-testimony animate-box">
						<blockquote>
							<span class="quote"><span><i class="icon-quote"></i></span></span>
							<p>&ldquo;Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.&rdquo;</p>
						</blockquote>
						<p class="author">John Doe, Founder <a href="#">FREEHTML5.co</a> <span class="subtext">Creative Director</span></p>
					</div>
					
				</div>
			</div>
		</div>
	</div>

	<div id="fh5co-blog" class="fh5co-bg-section">
		<div class="container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
					<h2>Recent Blog</h2>
					<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-4 col-md-4">
					<div class="fh5co-blog animate-box">
						<a href="#"><img class="img-responsive" src="images/34.jpg" alt=""></a>
						<div class="blog-text">
							<h3><a href=""#>SUPER FAMILY<br>328+ Channels & Services</a></h3>
							<span class="posted_on">Channels Info</span>
							<span class="comment"><a href="">21<i class="icon-speech-bubble"></i></a></span>
							<p><ul>
							<li>The popular choice for family entertainment</li>
							<li>Range of hindi and regional channels</li>
							<li>Enjoy Movies,News,Music with the best of kids & infotainment</li> </p>
							<a href="#" class="btn btn-primary">Read More</a>
						</div> 
					</div>
				</div>
				<div class="col-lg-4 col-md-4">
					<div class="fh5co-blog animate-box">
						<a href="#"><img class="img-responsive" src="images/34.jpg" alt=""></a>
						<div class="blog-text">
							<h3><a href=""#>SUPER FAMILY HD<br>335+ Channels & Services</a></h3>
							<span class="posted_on">Channels Info</span>
							<span class="comment"><a href="">21<i class="icon-speech-bubble"></i></a></span>
							<p><ul>
							<li>The popular choice for family entertainment</li>
							<li>Range of hindi and regional channels</li>
							<li>Enjoy Movies,News,Music with the best of kids & infotainment</li> </p>
							<a href="#" class="btn btn-primary">Read More</a>
						</div> 
					</div>
				</div>
				<div class="col-lg-4 col-md-4">
					<div class="fh5co-blog animate-box">
						<a href="#"><img class="img-responsive" src="images/34.jpg" alt=""></a>
						<div class="blog-text">
							<h3><a href=""#>MAXI KIDS<br>35+ channels</a></h3>
							<span class="posted_on">Channels Info</span>
							<span class="comment"><a href="">21<i class="icon-speech-bubble"></i></a></span>
							<p><ul>
							<li>Ideal Packs designed for kids </li>
							<li>Combines Family entertainment</li>
							<li>Including Kids channels,domestic leagues and world wrestling</li></p>
							<a href="#" class="btn btn-primary">Read More</a>
						</div> 
					</div>
				</div>


			</div>
		</div>
	</div>


	
<?php
include("footer.php");
?>