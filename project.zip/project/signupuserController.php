<?php 
include("MyDBClass.php");
if(isset($_POST["nameText"])  && isset($_POST["cityText"]) && isset($_POST["stateText"]) && isset($_POST["addressText"]) && isset($_POST["phoneText"]) && isset($_POST["emailText"])  && isset($_POST["passwordText"]))
{
	$name=$_POST["nameText"];
	$pass=$_POST["passwordText"];
	$city=$_POST["cityText"];
	$state=$_POST["stateText"];
	$phone=$_POST["phoneText"];
	$email=$_POST["emailText"];
	$address=$_POST["addressText"];
	
	$db=new MYDBClass;
     $ret=$db->insertUserDetails($name,$address,$city,$state,$phone,$email,$pass);//
	 if($ret>0)
	 {
		 session_start();
		 $_SESSION["userSess"]=	$email; 
		 header("location:login.php?msg=success");

	 }
	 else
	 {
		 header("location:signup.php?msg=fail");
	}
}
 else{
		header("location:signup.php?msg=invalid");
	 }
