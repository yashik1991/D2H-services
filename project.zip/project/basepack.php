
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css" integrity="sha384-Smlep5jCw/wG7hdkwQ/Z5nLIefveQRIY9nfy6xoR1uRYBtpZgI6339F5dgvm/e9B" crossorigin="anonymous">

    <title>HD Defination Packs</title>
	<link rel="stylesheet" type="text/css" href="hddefinitionpacks.css">
<header class="header">
 <div class="overlay"></div>
 <div class="container">y``
  
  </header>
 
  </head>
  <body>
    <script type="text/javascript" src='hddefinitionpacks.js'></script>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/js/bootstrap.min.js" integrity="sha384-o+RDsa0aLu++PJvFqy8fFScvbHFLtbvScb8AjopnFD+iEQ7wo/CG0xlczd+2O/em" crossorigin="anonymous"></script>
	<nav class="navbar navbar-expand-lg fixed-top ">
   <a class="navbar-brand" href="#">Home</a>
   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
     <span class="navbar-toggler-icon"></span>
   </button>
<div class="collapse navbar-collapse " id="navbarSupportedContent">
     <ul class="navbar-nav mr-4">
       
       <li class="nav-item">
         <a class="nav-link" href="#">Base Packs</a>
       </li>
       <li class="nav-item">
         <a class="nav-link " href="#">Hi Definition Packs</a>
       </li>
       <li class="nav-item">
         <a class="nav-link " href="#">Add-ons Packs</a>
       </li>
       <li class="nav-item">
         <a class="nav-link " href="#">My Packs</a>
       </li>
     </ul>
     
   </div>
</nav>

    <div>
		<div class="col-lg-4 col-md-4">
					<div class="fh5co-blog animate-box" style="float:left";>
						<a href="#"><img class="img-responsive" src="images/34.jpg" alt=""></a>
						<div class="blog-text">
							<h3><a href=""#>SUPER FAMILY<br>328+ Channels & Services</a></h3>
							<span class="posted_on">Channels Info</span>
							<span class="comment"><a href="">21<i class="icon-speech-bubble"></i></a></span>
							<p><ul>
							<li>The popular choice for family entertainment</li>
							<li>Range of hindi and regional channels</li>
							<li>Enjoy Movies,News,Music with the best of kids & infotainment</li> </p>
							<a href="#" class="btn btn-primary">Read More</a>
						</div> 
					</div>
				</div>
				 <div class="col-lg-4 col-md-4" style="float:left";">
					<div class="fh5co-blog animate-box">
						<a href="#"><img class="img-responsive" src="images/34.jpg" alt=""></a>
						<div class="blog-text">
							<h3><a href=""#>SUPER FAMILY<br>328+ Channels & Services</a></h3>
							<span class="posted_on">Channels Info</span>
							<span class="comment"><a href="">21<i class="icon-speech-bubble"></i></a></span>
							<p><ul>
							<li>The popular choice for family entertainment</li>
							<li>Range of hindi and regional channels</li>
							<li>Enjoy Movies,News,Music with the best of kids & infotainment</li> </p>
							<a href="#" class="btn btn-primary">Read More</a>
						</div> 
					</div>
				</div>
				
				<div class="col-lg-4 col-md-4" style="float:left";">
					<div class="fh5co-blog animate-box">
						<a href="#"><img class="img-responsive" src="images/34.jpg" alt=""></a>
						<div class="blog-text">
							<h3><a href=""#>SUPER FAMILY<br>328+ Channels & Services</a></h3>
							<span class="posted_on">Channels Info</span>
							<span class="comment"><a href="">21<i class="icon-speech-bubble"></i></a></span>
							<p><ul>
							<li>The popular choice for family entertainment</li>
							<li>Range of hindi and regional channels</li>
							<li>Enjoy Movies,News,Music with the best of kids & infotainment</li> </p>
							<a href="#" class="btn btn-primary">Read More</a>
						</div> 
					</div>
				</div>
		</div>
    </div>
  </div>
 

  </body>
</html>








