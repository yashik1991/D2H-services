<?php
	include("MyDBClass.php");
// Starting session
session_start();
?>
<!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>D2H connection services</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Website Template by FreeHTML5.co" />
	<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
	<meta name="author" content="FreeHTML5.co" />

	<!-- 
	//////////////////////////////////////////////////////

	FREE HTML5 TEMPLATE 
	DESIGNED & DEVELOPED by FreeHTML5.co
		
	Website: 		http://freehtml5.co/
	Email: 			info@freehtml5.co
	Twitter: 		http://twitter.com/fh5co
	Facebook: 		https://www.facebook.com/fh5co

	//////////////////////////////////////////////////////
	 -->

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href='https://fonts.googleapis.com/css?family=Work+Sans:400,300,600,400italic,700' rel='stylesheet' type='text/css'>
	<link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700" rel="stylesheet">
	
	<link rel="stylesheet" type="text/css" href="css/slideshow.css">
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>

	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>
	<body>
	
<div class="fh5co-loader"></div>
	
	<div id="page">
<nav class="fh5co-nav" role="navigation" style="background-color:rgba(0,0,0,0.7); padding:15px 0">
		<div class="container">
			<div class="row">
				<div class="left-menu text-right menu-1">
					<ul>
						<li class="has-dropdown"><a href="settopbox.php">Set Top Box</a>
							<ul class="dropdown">
								<li><?php 
										$obj=new MyDBClass;
										$row=$obj->displaySettopbox();
										
										while($res=mysqli_fetch_array($row))
										{
									?>
									<a href="settopbox.php?boxid=<?php echo $res['id'];?>"><?php echo $res['name']; ?></a>
									<?php
										}
									?>
								</li></ul>
						</li>
						<li class="has-dropdown"><a href="services.php">Services</a>
							<ul class="dropdown">
								<li><?php 
										$obj=new MyDBClass;
										$row=$obj->displayPackages();
										
										while($res=mysqli_fetch_array($row))
										{
									?>
									<a href="hddefinitionpacks.php"><?php echo $res['name']; ?></a>
									<?php
										}
									?>
								</li>
							</ul>
							</li>
						
							<li class="has-dropdown">
							<a href="categories.php">Category </a>
							 
							<ul class="dropdown">
								
								<li><?php 
										$obj=new MyDBClass;
										$row=$obj->displayCategory();
										
										while($res=mysqli_fetch_array($row))
										{
									?>
									<a href="displayPackageChannel.php?packId=<?php echo $res['id']; ?>"><?php echo $res['name']; ?></a>
									<?php
										}
									?>
								</li>
								<!--<li><a href="basepack.php">Base Packs</a></li>
								<li><a href="addon.php">Add-on Packs</a></li>
								<li><a href="selfpack.php">Mera Apna Pack</a></li>
								<li><a href="pickchannel.php">Pick By Channel</a></li> -->
							
							</ul></li>
								<!--a href="basepack.php">Base Packs</a></li>
								<li><a href="addon.php">Add-on Packs</a></li>
								<li><a href="selfpack.php">Mera Apna Pack</a></li>
								<li><a href="pickchannel.php">Pick By Channel</a></li-->
							
							</ul>
				</div>
<script>
$(document).ready(function(){
  $('.dropdown a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});
</script>

				<div class="logo text-center">
					<div id="fh5co-logo"><a href="#">D2H services</a></div>
				</div>
				<div class="right-menu text-left menu-1">
					<ul>
					<?php 
						if(isset($_SESSION["userSess"]))
						{
					?>
						<li><a href="../view/logout.php">Logout</a></li>
						<li class="has-dropdown">
							<a href="profile.php">Profile</a>
						</li>
						<?php
						}
						else
						{
						?>
						<li><a href="login.php">Login</a></li>
						<li class="has-dropdown">
							<a href="signup.php">Sign Up</a>
						</li>
						<?php
						}
						?>
						<li><a href="customerservices.php">Customer Care</a></li>
					</ul>
				</div>
			</div>
			
		</div>
	</nav>
		<div class="overlay"></div>
			<?php
	            include("aimgslider.php");
            ?>
		</div>