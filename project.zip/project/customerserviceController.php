<?php
	include("MyDBClass.php");
	session_start();
	if(isset($_POST['name']) && isset($_POST['message']))
	{
		$name= $_POST['name'];
		$visitor_email=$_SESSION["userSess"];
		$message= $_POST['message'];
		
		$obj=new MyDBClass;
		$res=$obj->customerCare($name,$visitor_email,$message);
		
		if($res!=null)
		{
			header("Location:index.php?msg=success");
  		}
	}		
	else
	{
		header('location:customerservices.php?msg=fail');
	}		
?>
	 
   