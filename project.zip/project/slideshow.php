
	<!DOCTYPE html>
<html>
<head>
	<title>Javascript Slideshow</title>
	<link rel="stylesheet" type="text/css" href="slideshow.css">
</head>
<body>
	<div id="container">
		<img class="slides" src="images/tvshow1.jpg">
		<img class="slides" src="images/tvshow2.jpg">
		<img class="slides" src="images/tvshow3.jpg">
		<img class="slides" src="images/tvshow4.jpg">
		<img class="slides" src="images/tvshows5.jpg">
		<button class="btn" onclick="plusIndex(-1)" id="prev">&#10094;</button>
		<button class="btn" onclick="plusIndex(1)" id="next">&#10095;</button>
	</div>
	
	

</body>
<script>
	var index=1;
	function plusIndex(n)
	{
		index=index+1;
		showImage(index);
	}
	showImage(1);
    function showImage(n) {
		var i;
		var x=document.getElementsByClassName("slides");
		if(n>x.length){index=1};
		if(n<1){index=xlength};
		for ( i=0; i<x.length;i++)
		{
			x[i].style.display="none";
		}
		x[index-1].style.display="block";
	}
</script>


</html>
	
	





