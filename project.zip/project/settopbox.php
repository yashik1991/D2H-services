<?php
	include('MyDBClass.php');
	$obj=new MyDBClass;
	
	$id=$_GET['boxid'];
	
	$r=$obj->displaysetTopboxs();
										
	while($res=mysqli_fetch_array($r))
	{
		//echo $res['id']."<br/>";
		echo $res['name']."<br/>";
		echo "<img src='admin/".$res['picsource']."' alt='boxPhoto' width=150px height=150px /><br/>";
	}
	
	/*$row=$obj->displaysetTopbox($id);
	
		echo $res['id']."<br/>";
		echo $res['name']."<br/>";
		echo $res['cost']."<br/>";
		echo $res['picsource'];*/
		
?>