<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css" integrity="sha384-Smlep5jCw/wG7hdkwQ/Z5nLIefveQRIY9nfy6xoR1uRYBtpZgI6339F5dgvm/e9B" crossorigin="anonymous">

    <title>HD Defination Packs</title>
	<link rel="stylesheet" type="text/css" href="addon.css">
<!-- <header class="header"> -->
 <!-- <!--div class="overlay"></div> -->
 <!-- <div class="container"-->
  
  <!-- </header> -->
 <meta charset ="utf-8">
 <meta charset="viewport" content="width=device-width,initial-scale=1">
 
  <body>
    <nav class="navbar navbar-expand-lg">
   <a class="navbar-brand" href="#">Home</a>
   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
     <span class="navbar-toggler-icon"></span>
   </button>
<div class="collapse navbar-collapse " id="navbarSupportedContent">
     <ul class="navbar-nav mr-4">
       
       <li class="nav-item">
         <a class="nav-link" href="#">Base Packs</a>
       </li>
       <li class="nav-item">
         <a class="nav-link " href="#">Hi Definition Packs</a>
       </li>
       <li class="nav-item">
         <a class="nav-link " href="#">Add-ons Packs</a>
       </li>
       <li class="nav-item">
         <a class="nav-link " href="#">My Packs</a>
       </li>
     </ul>
     
   </div>
</nav>

<div style="padding:60px;">
<div class="left" style="background-color:dimgrey">

<button type="button" class="btn btn-primary" style="margin-top:10px;width:170px;height:42px;">HD-Addon's</button><br>
<button type="button" class="btn btn-secondary" style="margin-top:10px;width:170px;height:42px;">Hindi Gen</button><br>
<button type="button" class="btn btn-success" style="margin-top:10px;width:170px;,height:50px;">English Entertainment<br> & Movies</button><br>
<button type="button" class="btn btn-danger" style="margin-top:10px;width:170px;,height:50px;">Sports</button><br>
<button type="button" class="btn btn-warning" style="margin-top:10px;width:170px;,height:50px;">English News</button><br>
<button type="button" class="btn btn-info" style="margin-top:10px;width:170px;,height:50px;">Kids</button><br>
<button type="button" class="btn btn-info" style="margin-top:10px;width:170px;,height:50px;">Infotainment <br>& Lifestyle</button><br>
<button type="button" class="btn btn-dark" style="margin-top:10px;width:170px;,height:50px;">Music</button><br>
<button type="button" class="btn btn-dark" style="margin-top:10px;width:170px;,height:50px;">Devotional</button><br>
<button type="button" class="btn btn-dark" style="margin-top:10px;width:170px;,height:50px;">North Regional<br>Entertainment<br>Add-ons</button><br>
<button type="button" class="btn btn-dark" style="margin-top:10px;width:170px;,height:50px;">South Regional<br> Entertainment</button><br>
<button type="button" class="btn btn-dark" style="margin-top:10px;width:170px;,height:50px;">Devotional</button><br>


</div>
<div class="right-text">


</div>

</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/js/bootstrap.min.js" integrity="sha384-o+RDsa0aLu++PJvFqy8fFScvbHFLtbvScb8AjopnFD+iEQ7wo/CG0xlczd+2O/em" crossorigin="anonymous"></script>
	<script type="text/javascript" src='addon.js'></script>
	</div>
</body>
</html>