<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css" integrity="sha384-Smlep5jCw/wG7hdkwQ/Z5nLIefveQRIY9nfy6xoR1uRYBtpZgI6339F5dgvm/e9B" crossorigin="anonymous">

    <title>HD Defination Packs</title>
	<link rel="stylesheet" type="text/css" href="css/basepack.css">
<!-- <header class="header"> -->
 <!-- <!--div class="overlay"></div> -->
 <!-- <div class="container"-->
  
  <!-- </header> -->
 <meta charset ="utf-8">
 <meta charset="viewport" content="width=device-width,initial-scale=1">
</head>
  <body>
    <nav class="navbar navbar-expand-lg">
   <a class="navbar-brand" href="index.php">Home</a>
   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
     <span class="navbar-toggler-icon"></span>
   </button>
<div class="collapse navbar-collapse " id="navbarSupportedContent">
     <ul class="navbar-nav mr-4">
       
       <!--li class="nav-item">
         <a class="nav-link" href="#">Base Packs</a>
       </li>
       <li class="nav-item">
         <a class="nav-link " href="#">Hi Definition Packs</a>
       </li>
       <li class="nav-item">
         <a class="nav-link " href="#">Add-ons Packs</a>
       </li>
       <li class="nav-item">
         <a class="nav-link " href="#">My Packs</a>
       </li-->
     </ul>
     
   </div>
</nav>
<?php
	include("MyDBClass.php");
	session_start();
	$user=$_SESSION['userSess'];
	
	$obj=new MyDBClass;
	$row=$obj->displayProfile($user);
	?>
	<div class="bs-example4" data-example-id="contextual-table">
						<table class="table">
						  <thead>
							<tr>
								<!--th>Image.</th-->
								<th>Name.</th>
								<th>Address.</th>
								<th>City.</th>
								<th>State.</th>
								<th>Phone.</th>
								<th>Email.</th>
								<!--th>Category.</th-->
								<th colspan="2">Operation</th>
							</tr>
						  </thead>
						  <tbody>
							<tr class="active">

<?php
		while($res=mysqli_fetch_array($row))
		{
			echo "
					
					<td>".$res['name']."</td>
					<td>".$res['address']."</td>
					<td>".$res['city']."</td>
					<td>".$res['state']."</td>
					<td>".$res['phone']."</td>
					<td>".$res['email']."</td>
					<td><a href='editprofile1.php?id=".$res['id']."&name=".$res['name']."&email=".$res['email']."&state=".$res['state']."&address=".$res['address']."&city=".$res['city']."&phone=".$res['phone']."'>Edit</a></td>
				 </tr>";
		}
	
	
?>
						</tbody>
					</table>
	</div>
</body>
</html>