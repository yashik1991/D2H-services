<?php
	session_start();
	$user=$_SESSION["userSess"];
?>
<html>
<head>
<title>Contact Us</title>
<link rel="stylesheet" type="text/css" href="css/customerservice.css">
<head>
<body>
<div class="contact-title">
<h1>Say Hello</h1>
<h2>We are always ready to serve you</h2>
</div>
<div class="contact-form">
<form id="contact-form" method="post" action="customerserviceController.php">
<input name="name" type="text" class="form-control" placeholder="Your name" required /><br/>
<input name="email" type="email" class="form-control"  disabled="disabled" placeholder="Your email" value="<?php echo $user; ?>" required /><br/>
<textarea name="message" class="form-control" placeholder="Message" row="4"required /></textarea><br/>
<input type="submit" class="form-control submit" value="SEND MESSAGE" />
</form>
</body>
</html>