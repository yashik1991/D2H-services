<html>
<head>
<title>Automatic image slider</title>
<link rel="stylesheet" type="aimgslider.css>
<style>
	.slide{
		width:100%;
		height:100%;
	}
</style>
</head>
<body>
<div class="slider" id="main-slider"><!-- outermost container element -->
	<div class="slider-wrapper"><!-- innermost wrapper element -->
		<!-- slides -->
		<img src="images/1.jpg" alt="Second" class="slide" />
	     <img src="images/2.jpg" alt="Third" class="slide" />
		 <img src="images/3.jpg" alt="Fourth" class="slide" />
		
		 <!--img src="images/bg31.jpg" alt="Six" class="slide" /-->
	</div>
</div>	

<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("slide");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 2000); // Change image every 2 seconds
}
</script>
</body>
</html>