<?php
	include('MyDBClass.php');
	
	$pid=$_GET['packId'];
	$obj=new MyDBClass;
	
	$pack=$obj->displayCategory();
?>	
	<table>
	<tr>
<?php	
	while($result=mysqli_fetch_array($pack))
	{
		echo "<td>".$result['name']."</td>"; 
	}

	$rs=$obj->selectPackage($pid);
	$r=mysqli_fetch_array($rs);
?>
	</tr><tr>
<?php
	
	echo "<td>".$r['name']."</td><td>".$r['id']."</td><td>".$r['cost']."</td><td>".$r['duration']."</td><td><img src=".$r['picsource']." alt='packImg' height=70px width=70px /></td><br/>";
?>
	</tr>
	</table>
	<table>
<?php
	$row=$obj->displayPackageChannels($pid);
	if($row!=null)
	{
		while($res=mysqli_fetch_array($row))
		{
			echo "<tr><td>".$res['name']."</td><td><img src=".$res['imgsource']." alt='packImg' height=45px width=45px /></td></tr>";
		}	 
?>
</table>
<input type="submit" name="Buy" id="id" value="BUY"/>
<?php 	
	}
?>


